from setuptools import setup
setup(
    name="superMathTestPaqueteDistri",
    version="1.0",
    description="Este es un paquete de prueba y no es nada serio",
    author="Alexis Narvaez",
    author_email="zaizealexis@gmail.com",
    url="",
    packages=['modules','modules']
)

#Este comando crea el paquete para poderlo distribuir
#python setup.py sdist